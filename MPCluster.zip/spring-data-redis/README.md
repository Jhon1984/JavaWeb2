## Spring Data Redis

### Relevant Articles:
- [Introduction to Spring Data Redis](http://www.baeldung.com/spring-data-redis-tutorial)
- [PubSub Messaging with Spring Data Redis](http://www.baeldung.com/spring-data-redis-pub-sub)

### Build the Project with Tests Running
```
mvn clean install
```

### Run Tests Directly
```
mvn test
```

